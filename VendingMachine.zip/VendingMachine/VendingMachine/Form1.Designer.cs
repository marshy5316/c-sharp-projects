﻿namespace VendingMachine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBuyChocolate = new System.Windows.Forms.Button();
            this.btnBuyCrisps = new System.Windows.Forms.Button();
            this.btnBuyWater = new System.Windows.Forms.Button();
            this.btnCheckStock = new System.Windows.Forms.Button();
            this.txtAmountOfItems = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBuyChocolate
            // 
            this.btnBuyChocolate.Location = new System.Drawing.Point(23, 73);
            this.btnBuyChocolate.Name = "btnBuyChocolate";
            this.btnBuyChocolate.Size = new System.Drawing.Size(116, 23);
            this.btnBuyChocolate.TabIndex = 0;
            this.btnBuyChocolate.Text = "Buy Chocolate ";
            this.btnBuyChocolate.UseVisualStyleBackColor = true;
            this.btnBuyChocolate.Click += new System.EventHandler(this.btnBuyChocolate_Click);
            // 
            // btnBuyCrisps
            // 
            this.btnBuyCrisps.Location = new System.Drawing.Point(23, 44);
            this.btnBuyCrisps.Name = "btnBuyCrisps";
            this.btnBuyCrisps.Size = new System.Drawing.Size(116, 23);
            this.btnBuyCrisps.TabIndex = 1;
            this.btnBuyCrisps.Text = "Buy Crisps ";
            this.btnBuyCrisps.UseVisualStyleBackColor = true;
            this.btnBuyCrisps.Click += new System.EventHandler(this.btnBuyCrisps_Click);
            // 
            // btnBuyWater
            // 
            this.btnBuyWater.Location = new System.Drawing.Point(23, 102);
            this.btnBuyWater.Name = "btnBuyWater";
            this.btnBuyWater.Size = new System.Drawing.Size(116, 23);
            this.btnBuyWater.TabIndex = 2;
            this.btnBuyWater.Text = "Buy Water";
            this.btnBuyWater.UseVisualStyleBackColor = true;
            this.btnBuyWater.Click += new System.EventHandler(this.btnBuyWater_Click);
            // 
            // btnCheckStock
            // 
            this.btnCheckStock.Location = new System.Drawing.Point(23, 131);
            this.btnCheckStock.Name = "btnCheckStock";
            this.btnCheckStock.Size = new System.Drawing.Size(116, 23);
            this.btnCheckStock.TabIndex = 3;
            this.btnCheckStock.Text = "Check Stock";
            this.btnCheckStock.UseVisualStyleBackColor = true;
            this.btnCheckStock.Click += new System.EventHandler(this.btnCheckStock_Click);
            // 
            // txtAmountOfItems
            // 
            this.txtAmountOfItems.Location = new System.Drawing.Point(23, 18);
            this.txtAmountOfItems.Name = "txtAmountOfItems";
            this.txtAmountOfItems.Size = new System.Drawing.Size(116, 20);
            this.txtAmountOfItems.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "enter amount ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(169, 168);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAmountOfItems);
            this.Controls.Add(this.btnCheckStock);
            this.Controls.Add(this.btnBuyWater);
            this.Controls.Add(this.btnBuyCrisps);
            this.Controls.Add(this.btnBuyChocolate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBuyChocolate;
        private System.Windows.Forms.Button btnBuyCrisps;
        private System.Windows.Forms.Button btnBuyWater;
        private System.Windows.Forms.Button btnCheckStock;
        private System.Windows.Forms.TextBox txtAmountOfItems;
        private System.Windows.Forms.Label label1;
    }
}

