﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace VendingMachine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        stock stock1 = new stock();
        private void btnBuyCrisps_Click(object sender, EventArgs e)
        {
            int a = stock1.chocolatestock();
            int ItemAmount = int.Parse(txtAmountOfItems.Text);
            stock1.BuyCrisps(ItemAmount);
            MessageBox.Show("you have purchased " + txtAmountOfItems.Text  + "packets of crisps");
            if (a < 0)
            {
                MessageBox.Show("this is empty");
            }

        }

        private void btnBuyChocolate_Click(object sender, EventArgs e)
        {
            int ItemAmount = int.Parse(txtAmountOfItems.Text);
            stock1.BuyChocolate(ItemAmount);
            MessageBox.Show("you have purchased " + txtAmountOfItems.Text + " chocolate bars");
        }

        private void btnBuyWater_Click(object sender, EventArgs e)
        {
            int ItemAmount = int.Parse(txtAmountOfItems.Text);
            stock1.BuyWater(ItemAmount);
            MessageBox.Show("you have purchased " + txtAmountOfItems.Text + "bottles of water");
        }

        private void btnCheckStock_Click(object sender, EventArgs e)
        {
            int a = stock1.chocolatestock();
            int b = stock1.waterstock();
            int c = stock1.crispsstock();

            string a2 = a.ToString();
            string b2 = b.ToString();
            string c2 = c.ToString();


            if (a <0) 
            {
                MessageBox.Show("this is empty");
            }
            if (b <0) 
            {
                MessageBox.Show("this is empty");
            }
            if (c <0) 
            {
                MessageBox.Show("this is empty");
            }

            MessageBox.Show("chocolate:"+a2 + "     water:"+b2 + "      crisps:"+c2);

        }

    }
}
