﻿using System;
using System.Windows.Forms;

namespace VendingMachine
{
    internal class stock
    {
        private int chocolate = 10;
        private int crisps = 10;
        private int water = 10;

        internal static int checkstock(int item)
        {
            throw new NotImplementedException();
        }

        public int BuyChocolate(int ItemAmount) 
        {
            chocolate = chocolate - ItemAmount;
            return chocolate;
        }

        public int BuyCrisps(int ItemAmount) 
        {
            crisps = crisps - ItemAmount;
            return crisps;
        }

        public int BuyWater(int ItemAmount) 
        { 
            water = water - ItemAmount;
            return water;
        }

        public int chocolatestock() 
        {
            return chocolate;        
        }
        public int waterstock()
        {
            return water;
        }
        public int crispsstock()
        {
            return crisps;
        }
    }
}
