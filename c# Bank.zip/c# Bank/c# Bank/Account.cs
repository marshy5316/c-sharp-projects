﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c__Bank
{
    internal class Account
    {

        //Attributes 
        private string CustomerName;
        private string AccountNumber;
        private decimal AccountBalance;

        // Methods
        public void MakeDeposit(decimal amount) 
        { 
            AccountBalance = AccountBalance + amount;
        }


        public decimal GetBalance() 
        {
            return AccountBalance;
        }

        public void WidthrawAmount(decimal amount) 
        {
            AccountBalance = AccountBalance - amount;
        }
    }
}
