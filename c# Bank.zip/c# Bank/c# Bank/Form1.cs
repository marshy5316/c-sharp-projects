﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c__Bank
{
    public partial class Bank : Form
    {
        public Bank()
        {
            InitializeComponent();
        }
        //Account Object
        Account account1;

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            //Create an account;

            account1 = new Account();
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            // Make a deposit

            //Input deposit amount
            decimal DepositAmount = decimal.Parse(txtDeposit.Text);
            account1.MakeDeposit(DepositAmount);
        }

        private void btnDisplayBalance_Click(object sender, EventArgs e)
        {
            //display balance 
            decimal Balance = account1.GetBalance();
            decimal MyBalance = Balance / 1000;
            if (MyBalance < 1)
            {
                MessageBox.Show("you got no bands");
            }
            else
            {
                MessageBox.Show("your balance is " + MyBalance + " bands");
            }
        }

        private void btnWidthraw_Click(object sender, EventArgs e)
        {
            decimal WidthdrawAmount = decimal.Parse(txtWidthraw.Text);
            decimal Balance = account1.GetBalance();
            if (WidthdrawAmount > Balance)
            {
                MessageBox.Show("i'm sorry you cant do that you'll go into overdraft");
            }
            else 
            {
                account1.WidthrawAmount(WidthdrawAmount);
                MessageBox.Show("you have widthdrew £" + WidthdrawAmount);
            }
        }
    }
}
