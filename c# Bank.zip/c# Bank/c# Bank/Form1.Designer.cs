﻿namespace c__Bank
{
    partial class Bank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDeposit = new System.Windows.Forms.TextBox();
            this.lblDepositAmount = new System.Windows.Forms.Label();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.btnDeposit = new System.Windows.Forms.Button();
            this.btnDisplayBalance = new System.Windows.Forms.Button();
            this.btnWidthraw = new System.Windows.Forms.Button();
            this.txtWidthraw = new System.Windows.Forms.TextBox();
            this.lblWidthraw = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtDeposit
            // 
            this.txtDeposit.Location = new System.Drawing.Point(12, 36);
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.Size = new System.Drawing.Size(110, 20);
            this.txtDeposit.TabIndex = 0;
            // 
            // lblDepositAmount
            // 
            this.lblDepositAmount.AutoSize = true;
            this.lblDepositAmount.Location = new System.Drawing.Point(9, 9);
            this.lblDepositAmount.Name = "lblDepositAmount";
            this.lblDepositAmount.Size = new System.Drawing.Size(82, 13);
            this.lblDepositAmount.TabIndex = 1;
            this.lblDepositAmount.Text = "Deposit Amount";
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.Location = new System.Drawing.Point(12, 101);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(110, 43);
            this.btnCreateAccount.TabIndex = 2;
            this.btnCreateAccount.Text = "Create Account";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // btnDeposit
            // 
            this.btnDeposit.Location = new System.Drawing.Point(12, 150);
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(110, 43);
            this.btnDeposit.TabIndex = 3;
            this.btnDeposit.Text = "Deposit Amount";
            this.btnDeposit.UseVisualStyleBackColor = true;
            this.btnDeposit.Click += new System.EventHandler(this.btnDeposit_Click);
            // 
            // btnDisplayBalance
            // 
            this.btnDisplayBalance.Location = new System.Drawing.Point(12, 199);
            this.btnDisplayBalance.Name = "btnDisplayBalance";
            this.btnDisplayBalance.Size = new System.Drawing.Size(110, 43);
            this.btnDisplayBalance.TabIndex = 4;
            this.btnDisplayBalance.Text = "Display Balance";
            this.btnDisplayBalance.UseVisualStyleBackColor = true;
            this.btnDisplayBalance.Click += new System.EventHandler(this.btnDisplayBalance_Click);
            // 
            // btnWidthraw
            // 
            this.btnWidthraw.Location = new System.Drawing.Point(12, 248);
            this.btnWidthraw.Name = "btnWidthraw";
            this.btnWidthraw.Size = new System.Drawing.Size(110, 43);
            this.btnWidthraw.TabIndex = 5;
            this.btnWidthraw.Text = "Withdraw Amount";
            this.btnWidthraw.UseVisualStyleBackColor = true;
            this.btnWidthraw.Click += new System.EventHandler(this.btnWidthraw_Click);
            // 
            // txtWidthraw
            // 
            this.txtWidthraw.Location = new System.Drawing.Point(12, 75);
            this.txtWidthraw.Name = "txtWidthraw";
            this.txtWidthraw.Size = new System.Drawing.Size(110, 20);
            this.txtWidthraw.TabIndex = 6;
            // 
            // lblWidthraw
            // 
            this.lblWidthraw.AutoSize = true;
            this.lblWidthraw.Location = new System.Drawing.Point(12, 59);
            this.lblWidthraw.Name = "lblWidthraw";
            this.lblWidthraw.Size = new System.Drawing.Size(97, 13);
            this.lblWidthraw.TabIndex = 7;
            this.lblWidthraw.Text = "Widthdraw Amount";
            // 
            // Bank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(137, 315);
            this.Controls.Add(this.lblWidthraw);
            this.Controls.Add(this.txtWidthraw);
            this.Controls.Add(this.btnWidthraw);
            this.Controls.Add(this.btnDisplayBalance);
            this.Controls.Add(this.btnDeposit);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.lblDepositAmount);
            this.Controls.Add(this.txtDeposit);
            this.Name = "Bank";
            this.Text = "Bank";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDeposit;
        private System.Windows.Forms.Label lblDepositAmount;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Button btnDeposit;
        private System.Windows.Forms.Button btnDisplayBalance;
        private System.Windows.Forms.Button btnWidthraw;
        private System.Windows.Forms.TextBox txtWidthraw;
        private System.Windows.Forms.Label lblWidthraw;
    }
}

