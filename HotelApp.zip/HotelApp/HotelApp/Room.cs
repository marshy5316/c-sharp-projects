﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelApp
{
    internal class Room
    {
        private string roomNumber;
        public bool roomtaken = false;
        
        public string GetCustomerName() 
        { 
            Customer customer = new Customer();
            return customer.GetName();
        }
        public string GetRoomNumber() 
        { 
            return roomNumber;
        }
        public bool isoccupied()
        {
            return roomtaken;


        }
        public void occupyroom() 
        { 
           roomtaken = true;
           
        }
        public void vacateroom() 
        { 
            roomtaken= false;
        }
    }
}
