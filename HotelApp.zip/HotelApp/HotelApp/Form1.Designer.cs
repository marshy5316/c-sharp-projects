﻿namespace HotelApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnBookRoom = new System.Windows.Forms.Button();
            this.btnCountCustomers = new System.Windows.Forms.Button();
            this.btnVacateRoom = new System.Windows.Forms.Button();
            this.btnShowIncome = new System.Windows.Forms.Button();
            this.btnReportRooms = new System.Windows.Forms.Button();
            this.gbVacateRoom = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.vacateroom = new System.Windows.Forms.Button();
            this.txtVacateRoom = new System.Windows.Forms.TextBox();
            this.gbBookRoom = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnBook = new System.Windows.Forms.Button();
            this.txtBookroom = new System.Windows.Forms.TextBox();
            this.menu = new System.Windows.Forms.GroupBox();
            this.btnAvailibility = new System.Windows.Forms.Button();
            this.gbReport = new System.Windows.Forms.GroupBox();
            this.btnReport = new System.Windows.Forms.Button();
            this.txtReport = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.IsAvailable = new System.Windows.Forms.ListBox();
            this.IsNotAvailable = new System.Windows.Forms.ListBox();
            this.gbVacateRoom.SuspendLayout();
            this.gbBookRoom.SuspendLayout();
            this.menu.SuspendLayout();
            this.gbReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBookRoom
            // 
            this.btnBookRoom.Location = new System.Drawing.Point(2, 18);
            this.btnBookRoom.Name = "btnBookRoom";
            this.btnBookRoom.Size = new System.Drawing.Size(136, 24);
            this.btnBookRoom.TabIndex = 0;
            this.btnBookRoom.Text = "Book Room";
            this.btnBookRoom.UseVisualStyleBackColor = true;
            this.btnBookRoom.Click += new System.EventHandler(this.btnBookRoom_Click);
            // 
            // btnCountCustomers
            // 
            this.btnCountCustomers.Location = new System.Drawing.Point(2, 48);
            this.btnCountCustomers.Name = "btnCountCustomers";
            this.btnCountCustomers.Size = new System.Drawing.Size(136, 28);
            this.btnCountCustomers.TabIndex = 1;
            this.btnCountCustomers.Text = "Count Customer";
            this.btnCountCustomers.UseVisualStyleBackColor = true;
            this.btnCountCustomers.Click += new System.EventHandler(this.btnCountCustomers_Click);
            // 
            // btnVacateRoom
            // 
            this.btnVacateRoom.Location = new System.Drawing.Point(2, 82);
            this.btnVacateRoom.Name = "btnVacateRoom";
            this.btnVacateRoom.Size = new System.Drawing.Size(137, 27);
            this.btnVacateRoom.TabIndex = 2;
            this.btnVacateRoom.Text = "Vacate Room";
            this.btnVacateRoom.UseVisualStyleBackColor = true;
            this.btnVacateRoom.Click += new System.EventHandler(this.btnVacateRoom_Click);
            // 
            // btnShowIncome
            // 
            this.btnShowIncome.Location = new System.Drawing.Point(2, 115);
            this.btnShowIncome.Name = "btnShowIncome";
            this.btnShowIncome.Size = new System.Drawing.Size(137, 32);
            this.btnShowIncome.TabIndex = 3;
            this.btnShowIncome.Text = "Show Income";
            this.btnShowIncome.UseVisualStyleBackColor = true;
            this.btnShowIncome.Click += new System.EventHandler(this.btnShowIncome_Click);
            // 
            // btnReportRooms
            // 
            this.btnReportRooms.Location = new System.Drawing.Point(1, 153);
            this.btnReportRooms.Name = "btnReportRooms";
            this.btnReportRooms.Size = new System.Drawing.Size(138, 30);
            this.btnReportRooms.TabIndex = 4;
            this.btnReportRooms.Text = "Report On Rooms";
            this.btnReportRooms.UseVisualStyleBackColor = true;
            this.btnReportRooms.Click += new System.EventHandler(this.btnReportRooms_Click);
            // 
            // gbVacateRoom
            // 
            this.gbVacateRoom.Controls.Add(this.label4);
            this.gbVacateRoom.Controls.Add(this.vacateroom);
            this.gbVacateRoom.Controls.Add(this.txtVacateRoom);
            this.gbVacateRoom.Location = new System.Drawing.Point(158, 151);
            this.gbVacateRoom.Name = "gbVacateRoom";
            this.gbVacateRoom.Size = new System.Drawing.Size(105, 100);
            this.gbVacateRoom.TabIndex = 5;
            this.gbVacateRoom.TabStop = false;
            this.gbVacateRoom.Text = "Vacate Room";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Customer Name";
            // 
            // vacateroom
            // 
            this.vacateroom.Location = new System.Drawing.Point(6, 71);
            this.vacateroom.Name = "vacateroom";
            this.vacateroom.Size = new System.Drawing.Size(92, 23);
            this.vacateroom.TabIndex = 1;
            this.vacateroom.Text = "vacate room";
            this.vacateroom.UseVisualStyleBackColor = true;
            this.vacateroom.Click += new System.EventHandler(this.vacateroom_Click);
            // 
            // txtVacateRoom
            // 
            this.txtVacateRoom.Location = new System.Drawing.Point(6, 45);
            this.txtVacateRoom.Name = "txtVacateRoom";
            this.txtVacateRoom.Size = new System.Drawing.Size(92, 20);
            this.txtVacateRoom.TabIndex = 0;
            // 
            // gbBookRoom
            // 
            this.gbBookRoom.Controls.Add(this.label2);
            this.gbBookRoom.Controls.Add(this.label1);
            this.gbBookRoom.Controls.Add(this.textBox1);
            this.gbBookRoom.Controls.Add(this.btnBook);
            this.gbBookRoom.Controls.Add(this.txtBookroom);
            this.gbBookRoom.Location = new System.Drawing.Point(158, 3);
            this.gbBookRoom.Name = "gbBookRoom";
            this.gbBookRoom.Size = new System.Drawing.Size(105, 142);
            this.gbBookRoom.TabIndex = 6;
            this.gbBookRoom.TabStop = false;
            this.gbBookRoom.Text = "Book Room";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "room number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "customer name";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 44);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(93, 20);
            this.textBox1.TabIndex = 2;
            // 
            // btnBook
            // 
            this.btnBook.Location = new System.Drawing.Point(7, 115);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(92, 23);
            this.btnBook.TabIndex = 1;
            this.btnBook.Text = "Book room";
            this.btnBook.UseVisualStyleBackColor = true;
            this.btnBook.Click += new System.EventHandler(this.btnBook_Click);
            // 
            // txtBookroom
            // 
            this.txtBookroom.Location = new System.Drawing.Point(7, 89);
            this.txtBookroom.Name = "txtBookroom";
            this.txtBookroom.Size = new System.Drawing.Size(92, 20);
            this.txtBookroom.TabIndex = 0;
            // 
            // menu
            // 
            this.menu.Controls.Add(this.btnAvailibility);
            this.menu.Controls.Add(this.btnBookRoom);
            this.menu.Controls.Add(this.btnCountCustomers);
            this.menu.Controls.Add(this.btnVacateRoom);
            this.menu.Controls.Add(this.btnReportRooms);
            this.menu.Controls.Add(this.btnShowIncome);
            this.menu.Location = new System.Drawing.Point(3, -2);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(144, 235);
            this.menu.TabIndex = 7;
            this.menu.TabStop = false;
            this.menu.Text = "menu";
            // 
            // btnAvailibility
            // 
            this.btnAvailibility.Location = new System.Drawing.Point(2, 189);
            this.btnAvailibility.Name = "btnAvailibility";
            this.btnAvailibility.Size = new System.Drawing.Size(137, 34);
            this.btnAvailibility.TabIndex = 5;
            this.btnAvailibility.Text = "show availability";
            this.btnAvailibility.UseVisualStyleBackColor = true;
            this.btnAvailibility.Click += new System.EventHandler(this.btnAvailibility_Click);
            // 
            // gbReport
            // 
            this.gbReport.Controls.Add(this.btnReport);
            this.gbReport.Controls.Add(this.txtReport);
            this.gbReport.Controls.Add(this.label3);
            this.gbReport.Location = new System.Drawing.Point(3, 238);
            this.gbReport.Name = "gbReport";
            this.gbReport.Size = new System.Drawing.Size(144, 110);
            this.gbReport.TabIndex = 8;
            this.gbReport.TabStop = false;
            this.gbReport.Text = "report on rooms";
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(6, 73);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(132, 23);
            this.btnReport.TabIndex = 2;
            this.btnReport.Text = "report";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // txtReport
            // 
            this.txtReport.Location = new System.Drawing.Point(6, 46);
            this.txtReport.Name = "txtReport";
            this.txtReport.Size = new System.Drawing.Size(132, 20);
            this.txtReport.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "customer name";
            // 
            // IsAvailable
            // 
            this.IsAvailable.FormattingEnabled = true;
            this.IsAvailable.Location = new System.Drawing.Point(276, 12);
            this.IsAvailable.Name = "IsAvailable";
            this.IsAvailable.Size = new System.Drawing.Size(155, 342);
            this.IsAvailable.TabIndex = 9;
            // 
            // IsNotAvailable
            // 
            this.IsNotAvailable.FormattingEnabled = true;
            this.IsNotAvailable.Location = new System.Drawing.Point(453, 12);
            this.IsNotAvailable.Name = "IsNotAvailable";
            this.IsNotAvailable.Size = new System.Drawing.Size(162, 342);
            this.IsNotAvailable.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 366);
            this.Controls.Add(this.IsNotAvailable);
            this.Controls.Add(this.IsAvailable);
            this.Controls.Add(this.gbReport);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.gbBookRoom);
            this.Controls.Add(this.gbVacateRoom);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "The Eagle Hotel ";
            this.TopMost = true;
            this.gbVacateRoom.ResumeLayout(false);
            this.gbVacateRoom.PerformLayout();
            this.gbBookRoom.ResumeLayout(false);
            this.gbBookRoom.PerformLayout();
            this.menu.ResumeLayout(false);
            this.gbReport.ResumeLayout(false);
            this.gbReport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBookRoom;
        private System.Windows.Forms.Button btnCountCustomers;
        private System.Windows.Forms.Button btnVacateRoom;
        private System.Windows.Forms.Button btnShowIncome;
        private System.Windows.Forms.Button btnReportRooms;
        private System.Windows.Forms.GroupBox gbVacateRoom;
        private System.Windows.Forms.Button vacateroom;
        private System.Windows.Forms.TextBox txtVacateRoom;
        private System.Windows.Forms.GroupBox gbBookRoom;
        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox menu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBookroom;
        private System.Windows.Forms.GroupBox gbReport;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.TextBox txtReport;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAvailibility;
        private System.Windows.Forms.ListBox IsAvailable;
        private System.Windows.Forms.ListBox IsNotAvailable;
        private System.Windows.Forms.Label label4;
    }
}

