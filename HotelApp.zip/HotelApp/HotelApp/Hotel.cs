﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelApp
{
    internal class Hotel
    {
        Dictionary<int,Room> roomsdict = new Dictionary<int,Room>();
        Dictionary<string, Customer>customers = new Dictionary<string, Customer>();
        Dictionary<int, bool> availibilityCheck = new Dictionary<int, bool>(); 
        public int count = 0;
        public Hotel() 
        {
            IEnumerable<int> rooms = Enumerable.Range(1, 40);
            foreach  ( int i in rooms)
            {
                Room room = new Room();
                roomsdict.Add(i, room);
            }
        }

        public int ReportOnRooms(string CustomerName)
        {
            
            if (customers.ContainsKey(CustomerName))
            {
                Customer customer = customers[CustomerName];
                int roomnumber = customer.roomNumber;
                return roomnumber;
            }

            else
            {
                return 0;
            }

            
        }

        public bool BookRoom(int roomNumber, string CustomerName)
        {
            
            if (customers.ContainsKey(CustomerName))
            {
                Customer customer1 = customers[CustomerName];
                if (customer1.roomNumber == 0)
                {
                    customers[CustomerName].roomNumber = roomNumber;
                    Customer customer = customers[CustomerName];
                    customer.roomNumber = roomNumber;
                    roomsdict[roomNumber].occupyroom();
                    count = count + 1;
                    return true;
                }
                else
                {
                    return false;
                }
                
                
            }
            else
            {
                Customer customer = new Customer();
                customer.roomNumber = roomNumber;
                customer.name = CustomerName;
                roomsdict[roomNumber].occupyroom();
                customers.Add(CustomerName, customer);
                count = count + 1;
                return true;
            }
            
        }

        public bool VacateRoom(string CustomerName)
        {
            if (customers.ContainsKey(CustomerName))
            {
                Customer customer1 = customers[CustomerName];
                if (customer1.roomNumber != 0)
                {
                    Customer customer = customers[CustomerName];
                    int roomNumber = customer.roomNumber;
                    roomsdict[roomNumber].vacateroom();
                    customer.roomNumber = 0;
                    count = count - 1;
                    return true;
                }
                else 
                { 
                    return false; 
                }

            }
            else 
            {
                return false;
            }
        }
        public int ShowIncome()
        {
            return count * 120;
        }
        public new Dictionary<int, bool> reportonallrooms()
        {
            IEnumerable<int> rooms2 = Enumerable.Range(1, 40);
            foreach (int i in rooms2) 
            {
                availibilityCheck[i] = roomsdict[i].roomtaken;
            }
            return availibilityCheck;
        }

        internal void VacateRoom(object customerName)
        {
            throw new NotImplementedException();
        }
    }
}
