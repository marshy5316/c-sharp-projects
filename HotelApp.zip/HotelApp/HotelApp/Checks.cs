﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelApp
{
    internal class Checks
    {
        public bool string_presence(string string1) 
        {
            if (string.IsNullOrEmpty(string1)){return false;}
            else{return true;}

        }
        public bool int_presence(int int1) 
        {
            string int2 = int1.ToString();
            if (string.IsNullOrEmpty(int2)){ return false;}
            else{return true;}
        }
        public bool bool_presence(bool bool1)
        {
            if( bool1 != true & bool1 != false){ return true;}
            else { return false;}
        }
        public bool intBoundryCheck(int UpperBound, int LowerBound, int number)
        {
            if(number<LowerBound || number > UpperBound){return false;}
            else{return true;}
        }

    }
}
