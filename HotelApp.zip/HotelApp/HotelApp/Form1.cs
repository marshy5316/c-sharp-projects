﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace HotelApp
{
    public partial class Form1 : Form
    {

       
        public Form1()
        {
            InitializeComponent();
            gbVacateRoom.Visible = false;
            gbBookRoom.Visible = false;
            gbReport.Visible = false;
            refresh();
        }
        Room room = new Room();
        Hotel hotel = new Hotel();
        Checks checks = new Checks();
        int revenue = 0;


        private void btnBookRoom_Click(object sender, EventArgs e)
        {
            gbBookRoom.Visible = true;
            menu.Visible = false;
        }

        private void btnVacateRoom_Click(object sender, EventArgs e)
        {
            menu.Visible = false;
            gbVacateRoom.Visible = true;

        }

        private void vacateroom_Click(object sender, EventArgs e)
        {
            string CustomerName = txtVacateRoom.Text;
            hotel.VacateRoom(CustomerName); 
            gbVacateRoom.Visible = false;
            menu.Visible = true;
            refresh();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            gbBookRoom.Visible = false;
            menu.Visible = true;
            try
            {
                if (checks.string_presence(txtBookroom.Text) == true & checks.string_presence(textBox1.Text) == true)
                {
                    hotel.BookRoom(int.Parse(txtBookroom.Text), textBox1.Text);
                    MessageBox.Show("room " + txtBookroom.Text + " is now booked");

                }
                else { MessageBox.Show("no details entered"); }
            }
            catch (Exception ex) { MessageBox.Show($"{ex.Message}"); }

            refresh();
            
        }

        private void btnShowIncome_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Current revenue is £{hotel.ShowIncome()}");
        }

        private void btnCountCustomers_Click(object sender, EventArgs e)
        {
            MessageBox.Show("the amount of customers are " + hotel.count.ToString());
        }

        private void btnReportRooms_Click(object sender, EventArgs e)
        {
            menu.Visible = false;
            gbReport.Visible = true;
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            menu.Visible = true;
            gbReport.Visible=false;
            string name = txtReport.Text;
            int numbah = hotel.ReportOnRooms(name);
            if (numbah == 0)
            {
                MessageBox.Show("customer does not exist");
            }
            else
            {
                MessageBox.Show(name + " is in this room " + " room: " + numbah);
            }
            refresh();
        }

        private void btnAvailibility_Click(object sender, EventArgs e)
        {
            refresh();
        }
        private void refresh()
        {
            
            Dictionary<int, bool> availibilityCheck = new Dictionary<int, bool>();
            List<string> messages = new List<string>();
            availibilityCheck = hotel.reportonallrooms();
            int i = 1;
            IsAvailable.Items.Clear();
            IsNotAvailable.Items.Clear();

            

            while (i <= 40)
            {
                if (availibilityCheck[i] == false)
                {
                    messages.Add("room " + i + " is available");
                    string temp = messages[i - 1];
                    IsAvailable.Items.Add(temp);
                    IsAvailable.ForeColor = Color.Green;
                }
                else
                {
                    messages.Add("room " + i + " is not availible");
                    string temp1 = messages[i - 1];
                    IsNotAvailable.Items.Add(temp1);
                    IsNotAvailable.ForeColor = Color.Red;

                }
                string temporal = messages[i - 1];
                i = i + 1;
            }
        }


    }
}
