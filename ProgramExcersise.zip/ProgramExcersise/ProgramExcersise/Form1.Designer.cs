﻿namespace ProgramExcersise
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtAmountOfMoney = new System.Windows.Forms.TextBox();
            this.txtAmountOfPeople = new System.Windows.Forms.TextBox();
            this.lblMoneyAmount = new System.Windows.Forms.Label();
            this.lblAmountOfPeople = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 38);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtAmountOfMoney
            // 
            this.txtAmountOfMoney.Location = new System.Drawing.Point(12, 80);
            this.txtAmountOfMoney.Name = "txtAmountOfMoney";
            this.txtAmountOfMoney.Size = new System.Drawing.Size(100, 20);
            this.txtAmountOfMoney.TabIndex = 1;
            // 
            // txtAmountOfPeople
            // 
            this.txtAmountOfPeople.Location = new System.Drawing.Point(12, 138);
            this.txtAmountOfPeople.Name = "txtAmountOfPeople";
            this.txtAmountOfPeople.Size = new System.Drawing.Size(100, 20);
            this.txtAmountOfPeople.TabIndex = 2;
            // 
            // lblMoneyAmount
            // 
            this.lblMoneyAmount.AutoSize = true;
            this.lblMoneyAmount.Location = new System.Drawing.Point(12, 64);
            this.lblMoneyAmount.Name = "lblMoneyAmount";
            this.lblMoneyAmount.Size = new System.Drawing.Size(88, 13);
            this.lblMoneyAmount.TabIndex = 3;
            this.lblMoneyAmount.Text = "amount of money";
            // 
            // lblAmountOfPeople
            // 
            this.lblAmountOfPeople.AutoSize = true;
            this.lblAmountOfPeople.Location = new System.Drawing.Point(9, 113);
            this.lblAmountOfPeople.Name = "lblAmountOfPeople";
            this.lblAmountOfPeople.Size = new System.Drawing.Size(89, 13);
            this.lblAmountOfPeople.TabIndex = 4;
            this.lblAmountOfPeople.Text = "amount of people";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(124, 171);
            this.Controls.Add(this.lblAmountOfPeople);
            this.Controls.Add(this.lblMoneyAmount);
            this.Controls.Add(this.txtAmountOfPeople);
            this.Controls.Add(this.txtAmountOfMoney);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtAmountOfMoney;
        private System.Windows.Forms.TextBox txtAmountOfPeople;
        private System.Windows.Forms.Label lblMoneyAmount;
        private System.Windows.Forms.Label lblAmountOfPeople;
    }
}

