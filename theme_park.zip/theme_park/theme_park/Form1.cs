﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace theme_park
{
    public partial class Theme_Park : Form
    {
        public Theme_Park()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int TicketSales = int.Parse(txtTicketAmount.Text);
                double price = 10.99;
                
                int goal = 40000;
                double amountMade = price * TicketSales;
                if (amountMade > goal) 
                {
                    txtResult.Clear();
                    txtResult.AppendText("Ticket Sales Are High!");
                }
                if (amountMade < goal) 
                {
                    txtResult.Clear();
                    txtResult.AppendText("Ticket Sales Are Low");
                }

                monthCalendar1.MaxSelectionCount = 1;
                string calendar_count = monthCalendar1.SelectionRange.Start.ToShortDateString();

                ticketsales.Items.Add("£" + amountMade + "  date:" + calendar_count);

                if (TicketSales > 10000) 
                {
                    MessageBox.Show("you are lying we can only fit 10,000");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("error occured: " + ex.Message);
            }
        }
    }
}
