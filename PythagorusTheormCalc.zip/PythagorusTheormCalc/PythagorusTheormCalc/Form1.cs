﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PythagorusTheormCalc
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        //squares the inputted A side in the text box
        float Asquared(float aside)
        {
            float AsideSquared = aside * aside;
            return AsideSquared;
        }

        //squares the inputted B side in the text box
        float Bsquared(float bside)
        {
            float BsideSquared = bside * bside;
            return BsideSquared;
        }

        //squares the result of the two functions  C side in the code
        float hsquared(float BsideSquared, float AsideSquared)
        {
             float Hsquared = BsideSquared + AsideSquared;
            float Hside = (float)Math.Sqrt(Hsquared);
            return Hside;
        }
        
        // displays the result of the calculations
        string displayresult(float Cside)
        {
            string result = Cside.ToString();
            txtC.Text = result;
            return result;
        }

        // what happens when the button is clicked
        private void button1_Click(object sender,  EventArgs e)
        {
            // variables 
            float aside = float.Parse(txtA.Text);
            float bside = float.Parse(txtB.Text);
            float a = Asquared(aside);
            float b = Bsquared(bside);
            float h = hsquared(a, b);
            displayresult(h);

        }
    }

}
