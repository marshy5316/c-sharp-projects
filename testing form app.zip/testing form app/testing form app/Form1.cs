﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace testing_form_app
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
           
            {

                int a, b, c;
                bool aok = int.TryParse(num1.Text, out a);

                bool bok = int.TryParse(num2.Text, out b);

                if (aok && bok)

                {

                    if (a >= 0 && b >= 0)

                    {

                        try

                        {

                            c = a / b;

                            MessageBox.Show("Answer is " + c);

                        }

                        catch (Exception ex)

                        {

                            MessageBox.Show(ex.Message);

                        }

                    }

                    else

                    {

                        MessageBox.Show("Numbers must be zero or positive");

                    }

                }

                else

                {

                    MessageBox.Show("Invalid input");

                }

            }

        }

    }
}

