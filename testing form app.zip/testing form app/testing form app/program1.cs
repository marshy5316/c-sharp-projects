﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testing_form_app
{
    internal class program1
    {
        ///private void btncalc_Click(object sender, EventArgs e)
        ///{



            ////try
            ////{
               ///// float number1 = float.Parse(num1.Text);
                /////float number2 = float.Parse(num2.Text);




               //// string calculation = (number1 / number2).ToString();
                ///MessageBox.Show("answer is " + calculation);
           /// }
            //catch (Exception ex)
            //{
                ///MessageBox.Show("Error Occured: " + ex.Message);
            //}
        //}
    }
}
