﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CementCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCementCalc_Click(object sender, EventArgs e)
        {
            //variables
            int amountOfCement;
            float costOfCement;
            string customerName;
            
            
            //calculations for bags of cement
            customerName = txtCustomerName.Text;
            amountOfCement = int.Parse(txtAmountOfCement.Text.ToString());
            costOfCement = amountOfCement * 0.93f;
            
            txtResult.Text = customerName + " you have bought " + amountOfCement.ToString() + " bags of cement costing £" + costOfCement.ToString();
        }
    }
}
