﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VanMovingCompany
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnvancalc_Click(object sender, EventArgs e)
        { 
            
            int NoOfItems;
            NoOfItems = int.Parse(txtNoOfItems.Text.ToString());
            string van_type;
            van_type = textBox1.ToString();

            if (van_type == "small")
            {
               if (NoOfItems < 30)
               {
                    MessageBox.Show("order placed price = £50");
               }
               if (NoOfItems > 30)
               {
                   MessageBox.Show("order too big for a small van items exceeded 30 " + "item amount: " + NoOfItems.ToString());
               }
            }
            if (van_type == "large")
            {
                if (NoOfItems < 60)
                {
                    MessageBox.Show("order placed price = £100");
                }
                if (NoOfItems > 60)
                {
                    MessageBox.Show("order too big for a large van items exceeded 60 " + "item amount: " + NoOfItems.ToString());
                }
            }
            if (van_type == "")
            {
                MessageBox.Show("a this van size van doesnt exist");
            }
            if (van_type != "Large") 
            {
                if (van_type != "small") 
                {
                    MessageBox.Show("this van type doesnt exist");
                }
            }

            if (NoOfItems < 0)
            {
                MessageBox.Show("you have nothing to move!");
            }   
                
            

        }
    }
}
